﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace MyNewFacebook.Models
{
    public class Status
    {
        public int StatusId { get; set; }
        [Required]
        public string StatusText { get; set; }

        public DateTime StatusDate { get; set; }

        public int NumberOfLikes { get; set; }

        public int MemberId { get; set; }
        public virtual Member Member { get; set; }
    }
}
