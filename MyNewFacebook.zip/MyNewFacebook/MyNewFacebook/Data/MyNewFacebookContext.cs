﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MyNewFacebook.Models;

namespace MyNewFacebook.Models
{
    public class MyNewFacebookContext : DbContext
    {
        public MyNewFacebookContext (DbContextOptions<MyNewFacebookContext> options)
            : base(options)
        {
        }

        public DbSet<MyNewFacebook.Models.Member> Member { get; set; }

        public DbSet<MyNewFacebook.Models.Status> Status { get; set; }
    }
}
