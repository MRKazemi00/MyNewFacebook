﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MyNewFacebook.Models;

namespace MyNewFacebook.Controllers
{
    [Authorize]
    public class StatusController : Controller
    {
        private readonly MyNewFacebookContext _context;

        public StatusController(MyNewFacebookContext context)
        {
            _context = context;
        }

        // GET: Status
        public async Task<IActionResult> Index(string sortOrder)
        {
            ViewBag.LikeSortParm=String.IsNullOrEmpty(sortOrder) ? "like_desc" : "";
            ViewBag.DateSortParm = sortOrder == "Date" ? "date_desc" : "Date";
           
            var statuses = _context.Status.Include(m => m.Member).OrderBy(s => s.NumberOfLikes);

            switch (sortOrder)
            {
                case "like_desc":
                    statuses = statuses.OrderByDescending(s => s.NumberOfLikes);
                    break;

                case "Date":
                    statuses = statuses.OrderBy(s => s.StatusDate);
                    break;

                case "date_desc":
                    statuses = statuses.OrderByDescending(s => s.StatusDate);
                    break;

                default:
                    statuses = statuses.OrderBy(s => s.NumberOfLikes);
                    break;
            }

            return View(await statuses.ToListAsync());
        }

        public async Task<IActionResult> IndexMemberStatus(int? id ,string sortOrder)
        {
            var Member = _context.Member.Where(m => m.MemberId == id);

            string name = Member.First().MemberName;

            ViewData["Member"] = name;

            ViewBag.LikeSortParm = String.IsNullOrEmpty(sortOrder) ? "like_desc" : "";
            ViewBag.DateSortParm = sortOrder == "Date" ? "date_desc" : "Date";

            var myFaceBookContext = _context.Status
                                           .Include(m => m.Member)
                                           .Where(s => s.MemberId == id);
            
            switch (sortOrder)
            {
                case "like_desc":
                    myFaceBookContext = myFaceBookContext.OrderByDescending(s => s.NumberOfLikes);
                    break;

                case "Date":
                    myFaceBookContext = myFaceBookContext.OrderBy(s => s.StatusDate);
                    break;

                case "date_desc":
                    myFaceBookContext = myFaceBookContext.OrderByDescending(s => s.StatusDate);
                    break;

                default:
                    myFaceBookContext = myFaceBookContext.OrderBy(s => s.NumberOfLikes);
                    break;
            }           
           
            return View(await myFaceBookContext.ToListAsync());
        }



        // GET: Status/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var status = await _context.Status
                .FirstOrDefaultAsync(m => m.StatusId == id);
            if (status == null)
            {
                return NotFound();
            }

            return View(status);
        }

        // GET: Status/Create
        public IActionResult Create()
        {
            ViewData["MemberId"] = new SelectList(_context.Set<Member>(), "MemberId", "MemberName");
            return View();
        }

        // POST: Status/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("StatusId,StatusText,StatusDate,NumberOfLikes,MemberId")] Status status)
        {
            if (ModelState.IsValid)
            {
                status.NumberOfLikes = 0;
                status.StatusDate = DateTime.Now;
                _context.Add(status);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MemberId"] = new SelectList(_context.Set<Member>(), "MemberId", "MemberName", status.MemberId);
            return View(status);
        }

        public async Task<IActionResult> Like(int? id)
        {
            var status = await _context.Status.FindAsync(id);
            status.NumberOfLikes++;
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

       

        // GET: Status/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var status = await _context.Status
                .FirstOrDefaultAsync(m => m.StatusId == id);
            if (status == null)
            {
                return NotFound();
            }

            return View(status);
        }

        // POST: Status/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var status = await _context.Status.FindAsync(id);
            _context.Status.Remove(status);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool StatusExists(int id)
        {
            return _context.Status.Any(e => e.StatusId == id);
        }
    }
}
